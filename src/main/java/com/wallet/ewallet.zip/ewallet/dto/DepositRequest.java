package com.wallet.ewallet.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class DepositRequest {
    private BigDecimal amount;
    private String successUrl;
    public BigDecimal getAmount() {
        return amount;
    }
}