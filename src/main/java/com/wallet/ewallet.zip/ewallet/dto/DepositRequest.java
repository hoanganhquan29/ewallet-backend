package com.wallet.ewallet.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class DepositRequest {
    private BigDecimal amount;

    public BigDecimal getAmount() {
        return amount;
    }
}